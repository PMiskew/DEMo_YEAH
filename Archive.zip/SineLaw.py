a = 0.1 + 0.1 + 0.1 == 0.3
print(a)

b = round(.1,1) + round(.1,1) + round(.1,1) == round(.3,1)
print(b)

c = round(.1 + .1 + .1,10) == round(.3,10)
print(c)


